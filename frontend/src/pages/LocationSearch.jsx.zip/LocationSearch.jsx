import React, { useState } from "react";
import axios from "axios";

const LocationSearch = () => {
  const [query, setQuery] = useState("");
  const [suggestions, setSuggestions] = useState([]);

  // LocationIQ API endpoint
  const apiKey = "pk.e14db5ac88f4d29e8f6eeafdc1981a37"; // Replace with your LocationIQ API key

  const handleSearch = async (e) => {
    const value = e.target.value;
    setQuery(value);

    if (value.length < 3) {
      setSuggestions([]); // Don't show suggestions for short queries
      return;
    }

    try {
      const response = await axios.get(
        `https://us1.locationiq.com/v1/search.php`,
        {
          params: {
            key: apiKey,
            q: value,
            format: "json",
            countrycodes: "IN",
            addressdetails: 1,
            language: "en", // Ensure results are in English
          },
        }
      );

      // Get the first three results and format their address
      const formattedSuggestions = response.data.map((item) => {
        return {
          description: `${item.address.station || ""} ${item.address.city || ""} ${item.address.state || ""} ${item.address.country || ""}`,
        };
      });

      setSuggestions(formattedSuggestions);
    } catch (error) {
      console.error("Error fetching location suggestions:", error);
    }
  };

  const handleSelect = (suggestion) => {
    setQuery(suggestion.description);
    setSuggestions([]);
  };

  return (
    <div className="w-full max-w-lg mx-auto p-4">
      <input
        type="text"
        value={query}
        onChange={handleSearch}
        placeholder="Enter a location in India"
        className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring focus:ring-blue-500"
      />
      {suggestions.length > 0 && (
        <ul className="border border-gray-300 rounded-lg mt-2 max-h-60 overflow-y-auto">
          {suggestions.map((suggestion, index) => (
            <li
              key={index}
              onClick={() => handleSelect(suggestion)}
              className="p-2 cursor-pointer hover:bg-gray-100"
            >
              {suggestion.description}
            </li>
          ))}
        </ul>
      )}
    </div>
  );
};

export default LocationSearch;
